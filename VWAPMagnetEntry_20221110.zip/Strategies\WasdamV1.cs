#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
    public class WasdamV1 : Strategy
    {
        private string longalert;
        private string shortalert;
        private string closelong;
        private string closeshort;

        private EMA ema;    // EMA 200
        private EMA ema2;   // EMA 800

        private RetWasdam ret;
        private double pos, posPrev = 0;

        public bool vold1, vold2, vold3;
        public bool volu1, volu2, volu3;

        private double buy1_sl = 0;
        private double buy2_sl = 0;
        private double buy3_sl = 0;
        private double buy4_sl = 0;
        private double buy5_sl = 0;

        private double sell1_sl = 0;
        private double sell2_sl = 0;
        private double sell3_sl = 0;
        private double sell4_sl = 0;
        private double sell5_sl = 0;

        double longStopPrice = 0.0;
        double longStopPrice2 = 0.0;
        double longStopPrice3 = 0.0;
        double longStopPrice4 = 0.0;
        double longStopPrice5 = 0.0;

        double longStopPrice_prev = 0.0;
        double longStopPrice_prev2 = 0.0;
        double longStopPrice_prev3 = 0.0;
        double longStopPrice_prev4 = 0.0;
        double longStopPrice_prev5 = 0.0;

        double shortStopPrice = 99999999;
        double shortStopPrice2 = 99999999;
        double shortStopPrice3 = 99999999;
        double shortStopPrice4 = 99999999;
        double shortStopPrice5 = 99999999;

        double shortStopPrice_prev = 99999999;
        double shortStopPrice_prev2 = 99999999;
        double shortStopPrice_prev3 = 99999999;
        double shortStopPrice_prev4 = 99999999;
        double shortStopPrice_prev5 = 99999999;

        NinjaTrader.Gui.Tools.SimpleFont myFont = new NinjaTrader.Gui.Tools.SimpleFont("Courier New", 12);
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "WasdamV1";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = false;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 30;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;

                // Parameters for MT4/5 Settings
                pc_risk = 2;        // default value : 2 , step : 0.1 , min value : 0
                pc_id = "";         // defval : "" , 
                pc_prefix = "";     // defval : ""

                // Parameters for EMA
                ema_len = 200;
                ema2_len = 800;

                // Parameters for Trend Trader
                Length = 21;
                Multiplier = 3;

                // Volume Based Colored Bars
                smaLength = 21;

                // Parameters
                longTrailPerc = 1;


                // Parameters for Alert
                double usef = pc_risk;
                var symbol = pc_prefix;
                longalert = pc_id + ",buy," + symbol + ",risk=" + usef.ToString("N2") + "";
                shortalert = pc_id + ",sell," + symbol + ",risk=" + usef.ToString("N2") + "";
                closelong = pc_id + ",closelong," + symbol + "";
                closeshort = pc_id + ",closeshort," + symbol + "";
            }
            else if (State == State.Configure)
            {
            }
            else if (State == State.DataLoaded)
            {
                // EMA 200
                ema = EMA(Close, ema_len);
                AddChartIndicator(ema);
                ChartIndicators[0].Plots[0].Brush = Brushes.Purple;
                ChartIndicators[0].Plots[0].Width = 3;

                // EMA 800
                ema2 = EMA(Close, ema2_len);
                AddChartIndicator(ema2);
                ChartIndicators[1].Plots[0].Brush = Brushes.Orange;
                ChartIndicators[1].Plots[0].Width = 3;

                // RET
                ret = RetWasdam(Length, Multiplier);
                AddChartIndicator(ret);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < BarsRequiredToTrade)
                return;
            //Add your custom strategy logic here.
            TrendTraderStrategy();
            VolumeBasedColoredBars();
            Strategy_1();
            //Strategy_2();
            //Strategy_3();
            //Strategy_4();
            //Strategy_5();
        }
        protected void TrendTraderStrategy()
        {
            pos = Close[0] > ret[0] ? 1 : Close[0] < ret[0] ? -1 : 0;

            if (pos != posPrev & pos == 1)
            {
                Alert("buyAlert", Priority.High, "Color changed - Buy", NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, Brushes.Black, Brushes.Yellow);
            }
            if (pos != posPrev & pos == -1)
            {
                Alert("sellAlert", Priority.High, "Color changed - Sell", NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, Brushes.Black, Brushes.Yellow);
            }
            posPrev = pos;
        }
        protected void VolumeBasedColoredBars()
        {
            double volume = VOL()[0];
            double avrg = SMA(VOL(), smaLength)[0];

            vold1 = volume > avrg * 1.5 & Close[0] < Open[0];
            vold2 = volume >= avrg * 0.5 & volume <= avrg * 1.5 & Close[0] < Open[0];
            vold3 = volume < avrg * 0.5 & Close[0] < Open[0];

            volu1 = volume > avrg * 1.5 & Close[0] > Open[0];
            volu2 = volume >= avrg * 0.5 & volume <= avrg * 1.5 & Close[0] > Open[0];
            volu3 = volume < avrg * 0.5 & Close[0] > Open[0];

            Brush cold1 = new SolidColorBrush(Color.FromRgb(128, 0, 0));
            Brush cold2 = new SolidColorBrush(Color.FromRgb(255, 0, 0));
            Brush cold3 = Brushes.Orange;
            Brush colu1 = new SolidColorBrush(Color.FromRgb(0, 100, 0));
            Brush colu2 = Brushes.Lime;
            Brush colu3 = new SolidColorBrush(Color.FromRgb(127, 255, 212));
            Brush color_1 = vold1 ? cold1 : vold2 ? cold2 : vold3 ? cold3 : volu1 ? colu1 : volu2 ? colu2 : volu3 ? colu3 : Brushes.White;

            BarBrush = color_1;

        }
        protected void Strategy_1()
        {
            bool buy1 = volu1 & CrossAbove(Close, ret, 1) & Close[0] > ema[0] & Close[0] > ema2[0] & Position.MarketPosition == MarketPosition.Flat;
            bool sell1 = vold1 & CrossBelow(Close, ret, 1) & Close[0] < ema[0] & Close[0] < ema2[0] & Position.MarketPosition == MarketPosition.Flat;

            if (buy1 & Position.MarketPosition == MarketPosition.Flat)
            {
                EnterLong("Buy1");
                buy1_sl = Low[1];
                longStopPrice_prev = buy1_sl;

                Draw.Text(this, "Buy1" + CurrentBar, false, "BUY-1", 0, Low[0], -30, Brushes.White, myFont, TextAlignment.Center, Brushes.Green, null, 1);
            }

            if (sell1 & Position.MarketPosition == MarketPosition.Flat)
            {
                EnterShort("Sell1");
                sell1_sl = High[1];
                shortStopPrice_prev = sell1_sl;

                Draw.Text(this, "Sell1" + CurrentBar, false, "SELL-1", 0, High[0], +30, Brushes.White, myFont, TextAlignment.Center, Brushes.Red, null, 1);
            }

            double shortTrailPerc = longTrailPerc; // input.float(title="Trail Short Loss (%)" , minval=0.0, step=0.1, defval=1) * 0.01

            // Determine trail stop loss prices
            double stopValue;

            if (Position.MarketPosition == MarketPosition.Long)
            {
                stopValue = Close[0] * (1 - longTrailPerc / 100);
                longStopPrice = Math.Max(stopValue, Math.Max(longStopPrice_prev, buy1_sl));
                Draw.Line(this, "Long" + CurrentBar, false, 1, longStopPrice_prev, 0, longStopPrice, Brushes.LimeGreen, DashStyleHelper.Solid, 2);
                longStopPrice_prev = longStopPrice;
            }


            if (Position.MarketPosition == MarketPosition.Short)
            {
                stopValue = Close[0] * (1 + shortTrailPerc / 100);
                shortStopPrice = Math.Min(stopValue, Math.Min(shortStopPrice_prev, sell1_sl));
                Draw.Line(this, "Long" + CurrentBar, false, 1, shortStopPrice_prev, 0, shortStopPrice, Brushes.Red, DashStyleHelper.Solid, 2);
                shortStopPrice_prev = shortStopPrice;
            }

            double long_sl1 = longStopPrice;
            double short_sl1 = shortStopPrice;

            if (Position.MarketPosition == MarketPosition.Long & Close[0] < long_sl1)
            {
                ExitLong();
                //Draw.Square(this, "ExBuy1Mark" + CurrentBar, false, 0, Low[0] - 70, Brushes.Green);
                Draw.Text(this, "ExBuy1Txt" + CurrentBar, false, "Ex-Buy1 \nStopLoss", 0, High[0], 30, Brushes.White, myFont, TextAlignment.Center, Brushes.Green, null, 1);
                Alert("closelong", Priority.High, closelong, NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, Brushes.Black, Brushes.Yellow);
            }
            if (Position.MarketPosition == MarketPosition.Short & Close[0] > short_sl1)
            {
                ExitShort();
                //Draw.Square(this, "ExSell1Mark" + CurrentBar, false, 0, Low[0] - 70, Brushes.Red);
                Draw.Text(this, "ExSell1Txt" + CurrentBar, false, "Ex-Sell1 \nStopLoss", 0, Low[0], -30, Brushes.White, myFont, TextAlignment.Center, Brushes.Red, null, 1);
                Alert("closeshort", Priority.High, closeshort, NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, Brushes.Black, Brushes.Yellow);
            }

        }

        #region Properties   

        // +------------------------------------------------------------+
        // | MT4/5  (order 1)
        // +------------------------------------------------------------+
        [NinjaScriptProperty]
        [Range(0, float.MaxValue)]
        [Display(Name = "Qty", Order = 1, GroupName = "MT4/5 Settings", Description = "Risk")]
        public float pc_risk
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "License ID", Order = 2, GroupName = "MT4/5 Settings", Description = "This is your license ID")]
        public string pc_id
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "MetaTrader Symbol", Order = 3, GroupName = "MT4/5 Settings", Description = "This is your broker's MetaTrader symbol name")]
        public string pc_prefix
        { get; set; }


        // +------------------------------------------------------------+
        // | EMA (order 2)
        // +------------------------------------------------------------+

        // EMA 200
        [NinjaScriptProperty]
        [Display(Name = "EMA1 Len", Order = 1, GroupName = "EMA", Description = "EMA 1 period")]
        public int ema_len
        { get; set; }

        // EMA 800
        [NinjaScriptProperty]
        [Display(Name = "EMA2 Len", Order = 2, GroupName = "EMA", Description = "EMA 2 period")]
        public int ema2_len
        { get; set; }

        // +------------------------------------------------------------+
        // | Trend Trader Strategy (grp3)
        // +------------------------------------------------------------+
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Length", Order = 1, GroupName = "Trend Trader Strategy", Description = "")]
        public int Length
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Multiplier", Order = 2, GroupName = "Trend Trader Strategy", Description = "")]
        public double Multiplier
        { get; set; }

        // +------------------------------------------------------------+
        // | Volume Based Coloured Bars (grp4)
        // +------------------------------------------------------------+
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "length", Order = 1, GroupName = "Volume Based Coloured Bars", Description = "")]
        public int smaLength
        { get; set; }

        // +------------------------------------------------------------+
        // | Parameters
        // +------------------------------------------------------------+
        [NinjaScriptProperty]
        [Display(Name = "Trail S.Loss (%)", Order = 0, GroupName = "Parameters", Description = "")]
        public double longTrailPerc
        { get; set; }
        #endregion
    }
}